#!/usr/bin/python3.6
#coding:utf-8
from src.gamemanager import GameManager

if __name__ == '__main__':
	gm = GameManager()
	gm.init_database()
	gm.start()