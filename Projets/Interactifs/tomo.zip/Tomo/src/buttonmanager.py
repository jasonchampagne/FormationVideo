#!/usr/bin/python3.6
#coding:utf-8
import pygame


class ButtonManager:
	def __init__(self, options : list):
		self.options_list = options
		self.number_of_options = len(options)
		self.renders_list = [None] * self.number_of_options
		self.active_option = 0

	def get_key_pressed(self, game_manager):
		return game_manager.current_event_manager.get_keyname()

	def update_active_button(self, key):
		if key == "down":
			# Si on appuie sur Bas
			self.active_option = (self.active_option + 1) % self.number_of_options
		elif key == "up":
			# Si on appuie sur Haut
			self.active_option = (self.active_option - 1) % self.number_of_options

	def check_validate_button(self, key):
		if key == "return":
			self.execute_button()

	def execute_button(self) :
		if self.button_callback[self.active_option] :
			args = self.button_callback_args[self.active_option]
			self.button_callback[self.active_option](*args)
			