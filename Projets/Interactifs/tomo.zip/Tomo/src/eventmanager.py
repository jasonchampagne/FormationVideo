#!/usr/bin/python3.6
#coding:utf-8
import pygame

class EventManager:
	def __init__(self):
		pass

	def help(self):
		# Affichage d'une pop-up des touches disponibles sur une scène spécifique
		print("ex : [C] Créer une partie")

	def get_keyname(self):
		for event in pygame.event.get():
			if event.type == pygame.KEYDOWN:
				return pygame.key.name(event.key)


if __name__ == '__main__':
	pass