#!/usr/bin/python3.6
#coding:utf-8
from src.menuscene import MenuScene
from src.eventmanager import EventManager
from src.database import Database
import pygame

class GameManager:
	def __init__(self):
		pygame.init()
		self.screen_size = (640, 480)
		self.screen = pygame.display.set_mode(self.screen_size)
		self.game_launched = True
		self.current_scene = None
		self.current_event_manager = None
		self.clock = None
		self.database = None
		self.title_menu_font_file = 'data/fonts/8bits.ttf'
		self.text_menu_font_file = 'data/fonts/8bits-regular.ttf'
		pygame.display.set_caption('Tomo')

	def init_database(self):
		self.database = Database.GetInstance('data/tomo.db')
		sql = "SELECT COUNT(id) FROM tomo"
		#TODO à récupérer pour la scène de menu
		tomo_counter = self.database.cursor.execute(sql).fetchone()[0]

	def start(self):
		self.current_event_manager = EventManager()
		self.current_scene = MenuScene(self, "Menu principal", (25, 25, 25))
		self.clock = pygame.time.Clock()
		pygame.display.flip()

		# BOUCLE PRINCIPALE DU JEU :)
		while self.game_launched:
			self.clock.tick(60)
			self.current_scene.update()