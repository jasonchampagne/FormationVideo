#!/usr/bin/python3.6
#coding:utf-8

from . database import Database
import random
import time
import sys

# info (0), warning (1), error (2), fatal (3)
class Logger:
	def __init__(self, tomo_name : str, level : int, message : str):
		self.tomo_name = tomo_name
		self.level = level
		self.message = message
		self.table_name = "logs"

	def write(self, db : Database):
		db.save(self.table_name, {'logdate' : time.strftime('%Y-%m-%d %H:%M:%S'), 
		                          'level' : self.level, 
								  'tomo' : self.tomo_name, 
								  'message' : self.message})

	def notify(self):
		print(f"({self.level}) {self.message}")

if __name__ == '__main__':
	pass