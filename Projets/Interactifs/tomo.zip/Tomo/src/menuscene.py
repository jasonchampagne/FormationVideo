#!/usr/bin/python3.6
#coding:utf-8
from src.scene import Scene
from src.buttonmanager import ButtonManager
from src.logger import Logger
import pygame


class MenuScene(Scene):
	def __init__(self, game_manager, name : str, background_color : tuple):
		super().__init__(game_manager, name, background_color)
		self.button_manager = ButtonManager(['Creer un Tomo', 'Charger une partie', 'Quitter le jeu'])
		self.button_manager.button_callback = [self.button_create, self.button_load, self.button_quit]
		self.button_manager.button_callback_args = [(), (), ()]
		self.inactive_color = (40, 100, 240) # bleu foncé
		self.active_color = (60, 180, 190) # bleu ciel
		self.title_font = pygame.font.Font(self.game_manager.title_menu_font_file, 100)
		self.menu_font = pygame.font.Font(self.game_manager.text_menu_font_file, 20)

	def handle_events(self):
		key = self.button_manager.get_key_pressed(self.game_manager)
		self.button_manager.update_active_button(key)
		self.button_manager.check_validate_button(key)

	def draw(self):
		self.game_manager.screen.fill(self.background_color)

		title = self.title_font.render('TOMO', True, (200, 200, 255))
		self.game_manager.screen.blit(title, (self.game_manager.screen_size[0] // 2 - title.get_width() // 2, 50))

		for i in range(self.button_manager.number_of_options) :
			# Création du render
			if i == self.button_manager.active_option:
				render = self.menu_font.render(self.button_manager.options_list[i], True, self.active_color)
			else:
				render = self.menu_font.render(self.button_manager.options_list[i], True, self.inactive_color)
			
			# Save du render dans le renders_list de button_manager
			self.button_manager.renders_list[i] = render

			# Affichage du button
			renderXPos = self.game_manager.screen_size[0] // 2 - render.get_width() // 2
			renderYPos = 350 - (self.button_manager.number_of_options // 2) * 50 + i * 50
			self.game_manager.screen.blit(render, (renderXPos, renderYPos))

		pygame.display.update()

	def update(self):
		self.handle_events()
		self.draw()

	#TODO à revoir au complet
	def button_create(event):
		# The past!
		# name = input("Choisir un nom pour votre Tomo : ")
		tomo = Tomo(name)
		
		if tomo.create_tomo(Globals.db):
			log = Logger(tomo.name, 0, f"Création du tomo {tomo.name}")
			log.write(Globals.db)
			return tomo

		return None

	#TODO à revoir au complet
	def button_load():
		name = input("Qui est ton Tomo jeune gourgandin ? ")
		print(f"Chargement de {name} en cours...")
		tomo = Tomo.get_tomo(Globals.db, name)

		if tomo is not None:
			log = Logger(tomo.name, 0, "Chargement de la partie")
			log.write(Globals.db)
		
		return tomo

	def button_quit(self):
		# log = Logger("Toto", 0, "Dead game")
		# log.write(self.game_manager.database)
		self.game_manager.database.disconnect()
		exit(0)