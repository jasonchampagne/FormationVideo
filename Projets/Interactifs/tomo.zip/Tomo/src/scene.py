#!/usr/bin/python3.6
#coding:utf-8
from abc import ABC, abstractmethod

"""
Objet du jeu
"""
class Scene(ABC):
	@abstractmethod
	def __init__(self, game_manager, name : str = "Scene", background_color : tuple = (0, 0, 0)):
		self.game_manager = game_manager
		self.name = name
		self.background_color = background_color
		
	@abstractmethod
	def handle_events(self):
		pass

	@abstractmethod
	def draw(self):
		pass

	@abstractmethod
	def update(self):
		pass