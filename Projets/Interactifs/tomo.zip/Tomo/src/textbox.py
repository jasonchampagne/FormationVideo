#!/usr/bin/python3.6
#coding:utf-8
import pygame

class TextBox:
	def __init__(self):
		#self.rect = pygame.Rect()
		self.focus = False
		self.text = ''

	def handle(self, event):
		if event.type == pygame.KEYDOWN:
			c = pygame.key.name(event.key)
			print(c)
			self.text += c

	def draw(self, window):
		pass