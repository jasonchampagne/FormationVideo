<?php
declare(strict_types = 1);
namespace app;

use core\Controller;

class NewsController extends Controller
{
    public function getAllNews(): void
    {
        $newsModel = $this->getModel("news");
        $allNews = $newsModel->getAllNewsFromDb();

        $this->injectData("h1_title", "Les infos du jour !");
        $this->injectData("listNews", $allNews);
        $this->renderView("allnews");
    }
}