<?php
declare(strict_types = 1);
namespace app;

use core\Controller;

class PageController extends Controller
{
    public function index(): void
    {
        $this->renderView("home");
    }

    public function show(): void
    {
        $this->injectData("h1_title", "Comment dire...");
        $this->renderView("other");
    }
}