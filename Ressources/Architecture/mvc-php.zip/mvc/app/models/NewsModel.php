<?php
declare(strict_types = 1);
namespace app;

class NewsModel
{
    /*
        Pour limiter le nombre de fichiers, j'ai inclus tout ce qui concerne la
        connexion et les requêtes à base SQL directement ici.

        Dans un projet "réel", on préfèrera concevoir une API pour la communication
        avec la base de données.

        Ce peut être une interface à implémenter, une classe, voire un trait
        utilisant le patron de conception Singleton (abordé sur la chaîne dans
        la même playlist, sinon il faut attendre la vidéo)
    */
    public function getAllNewsFromDb(): array
    {
        $options =
		[
			\PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4',
			\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
			\PDO::ATTR_EMULATE_PREPARES => false
		];

        $PDO = null;

		try
		{
			$PDO = new \PDO('mysql:host='.Config::SQL_HOST.';dbname='.Config::SQL_DATABASE, Config::SQL_USER, Config::SQL_PASSWORD, $options);

            $stmt = $PDO->prepare("SELECT * FROM mvc_news ORDER BY news_id DESC");
            $stmt->execute();
            $result = $stmt->fetchAll(\PDO::FETCH_OBJ);

            $stmt->closeCursor();
            return $result;
		}
		catch(\PDOException $e)
		{
			Error::printMessage($e->getMessage());
		}
    }
}