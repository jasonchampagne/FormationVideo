<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf8">
    <title>Accueil</title>
</head>
<body>
    <h1><?= $h1_title ?></h1>

    <?php foreach($listNews as $n): ?>
        <h2>--- <?= htmlspecialchars($n->news_title) ?></h2>
        <p>Le <?= htmlspecialchars(french_date($n->news_date)) ?> :<br>
        <?= htmlspecialchars($n->news_content) ?></p>
    <?php endforeach; ?>

    <hr>
    <p><a href="index.php">&raquo; Revenir en arrière</a></p>
</body>
</html>