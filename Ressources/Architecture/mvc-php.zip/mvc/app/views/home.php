<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf8">
    <title>Accueil</title>
</head>
<body>
    <h1>Bienvenue sur la page principale !</h1>

    <ul>
        <li><a href="data">Des données d'une base SQL</a></li>
        <li><a href="page">Une autre page</a></li>
        <li><a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" title="La Vérité...">42</a></li>
    </ul>
</body>
</html>