<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf8">
    <title>Accueil</title>
</head>
<body>
    <h1><?= $h1_title ?></h1>

    <p>Circulez, y'a rien à voir !</p>
    <p><a href="index.php">&raquo; Revenir en arrière</a></p>
</body>
</html>