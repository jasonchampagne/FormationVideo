<?php
declare(strict_types = 1);
namespace core;

if(!defined('ROOT')) exit('Nope !');

class Controller
{
    /** Données pour la vue */
    private array $_viewData = [];

    protected function renderView(string $name): void
    {
        $viewPath = ROOT.SEP.'app'.SEP.'views'.SEP.$name.'.php';

        if(file_exists($viewPath))
        {
            extract($this->_viewData);
            require $viewPath;
        }
        else
            Error::printMessage("Fichier de la vue introuvable");
    }

    protected function getModel(string $name): mixed
    {
        $modelName = ucfirst($name);
        $modelCompleteName = $modelName.'Model';
        $modelPath = ROOT.SEP.'app'.SEP.'models'.SEP.$modelCompleteName.'.php';

        if(file_exists($modelPath))
        {
            require $modelPath;

            $qualifiedName = '\app\\'.$modelCompleteName;
            return new $qualifiedName();
        }
        else
            Error::printMessage("Fichier du controleur introuvable");
    }

    protected function injectData(string $name, string|array $value)
    {
        $this->_viewData[$name] = $value;
    }
}