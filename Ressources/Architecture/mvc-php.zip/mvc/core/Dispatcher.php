<?php
declare(strict_types = 1);
namespace core;

if(!defined('ROOT')) exit('Nope !');

class Dispatcher
{
    /** URL demandée par l'utilisateur */
    private readonly string $_uri;

    public function __construct()
    {
        if(!empty($_GET['uri']))
			$this->_uri = trim($_GET['uri'], '/');
        else
            $this->_uri = "";
    }

    public function run(): void
    {
        /*
            On pourrait faire plus complet, parser l'URL,
            charger la bonne méthode suivant l'action
            demandée dans le contrôleur, optimiser les URLs, etc.
        */
        $whatController = "";
        $whatAction = "index";

        switch($this->_uri)
        {
            case "data":
                $whatController = "news";
                $whatAction = "getAllNews";
                break;
            case "page":
                $whatController = "page";
                $whatAction = "show";
                break;
            case "":
                $whatController = \app\Config::DEFAULT_CONTROLLER;
                $whatAction = \app\Config::DEFAULT_ACTION;
                break;
            default:
                Error::trigger404();
                break;
        }

        $this->loadController($whatController, $whatAction);
    }

    public function loadController(string $name, string $action): void
    {
        $controllerName = ucfirst($name).'Controller';
        $controllerPath = ROOT.SEP.'app'.SEP.'controllers'.SEP.$controllerName.'.php';

        if(file_exists($controllerPath))
        {
            require $controllerPath;

            $qualifiedName = '\app\\'.$controllerName;
            $c = new $qualifiedName();
            $c->$action();
        }
        else
            Error::printMessage("Fichier du controleur introuvable");
    }
}