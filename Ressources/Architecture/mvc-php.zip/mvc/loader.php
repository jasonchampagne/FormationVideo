<?php
declare(strict_types = 1);
if(!defined('ROOT')) exit('Nope !');

/*
    Avec spl_autoload_register(), ce sera
    encore mieux !
*/

require ROOT.SEP.'app'.SEP.'Config.php';
require ROOT.SEP.'core'.SEP.'Controller.php';
require ROOT.SEP.'core'.SEP.'Database.php';
require ROOT.SEP.'core'.SEP.'Dispatcher.php';
require ROOT.SEP.'core'.SEP.'Error.php';

// Fonctions utilitaires
require ROOT.SEP.'app'.SEP.'utils.php';