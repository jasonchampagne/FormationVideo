"""
    AnimalView
"""

def show(animals):
    for each in animals:
        print(each)
