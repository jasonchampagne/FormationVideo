/*
	[COMPILATION]

    GNU/Linux et MacOS
        > gcc main.c $(sdl2-config --cflags --libs) -o prog
        > gcc *.c $(sdl2-config --cflags --libs) -o prog
    Windows
        > gcc src/main.c -o bin/prog -I include -L lib -lmingw32 -lSDL2main -lSDL2
*/
#include <stdio.h>
#include <stdlib.h>
#include <SDL.h>

void SDL_ExitWithError(const char *message);

int main(int argc, char *argv[])
{
    SDL_version sv;

	SDL_VERSION(&sv);
    printf("Version SDL : %d.%d.%d\n", sv.major, sv.minor, sv.patch);
    
    return EXIT_SUCCESS;
}