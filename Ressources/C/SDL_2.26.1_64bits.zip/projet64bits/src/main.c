/*
    GNU/Linux et MacOS
        > gcc src/*.c -o bin/prog $(sdl2-config --cflags --libs)
    Windows
        > gcc src/*.c -o bin/prog -I include -L lib -lmingw32 -lSDL2main -lSDL2
*/
#include <SDL.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv)
{
    SDL_version number;

    SDL_VERSION(&number);
    printf("Bienvenue sur la SDL %d.%d.%d !\n", number.major, number.minor, number.patch);

    return 0;
}