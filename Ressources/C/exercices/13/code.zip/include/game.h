#ifndef __GAME__H__
    #define __GAME__H__
    #include <SDL2/SDL.h>
    #include <stdbool.h>

    /*
    * Représente un cube, une forme en 2D sur laquelle on simulera
    * de la physique (saut puis chute soumis aux lois de la gravité)
    */
    struct Cube
    {
        float x;        // position sur l'axe horizontal
        float y;        // position sur l'axe vertical
        float velocity; // vitesse actuelle de déplacement
        bool isJumping; // est-il en train de sauter ?
    };

    /*
        A. Fonction globale pour initialiser le jeu, qui appelera :
            - fonction pour initialiser la SDL (B)
            - fonction pour créer la fenêtre (C)
            - fonction pour créer le dispositif de rendu (D)
            - fonction pour créer le cube (E)
    */

    // B. Fonction pour initialiser la SDL
    // C. Fonction pour créer une fenêtre
    // D. Fonction pour créer le dispositif de rendu
    // E. Fonction pour créer le cube
    // F. Fonction pour capturer les évènements
    // G. Fonction pour mettre à jour la logique
    // H. Fonction pour rafraîchir le rendu
    // I. Fonction pour libérer les ressources

#endif