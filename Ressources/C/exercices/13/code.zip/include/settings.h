#ifndef __SETTINGS__H__
    #define __SETTINGS__H__

    /* Nom de la fenêtre de l'application */
    #define GAME_NAME "Saute-cube !"

    /* Résolution de la fenêtre */
    #define SCREEN_WIDTH 640
    #define SCREEN_HEIGHT 480

    /* Hauteur du sol (pixels) */
    #define GROUND_HEIGHT 20

    /* Longueur des côtés du cube (pixels) */
    #define CUBE_SIZE 50

    /* Force de gravité */
    #define GRAVITY_FORCE 0.5

    /* Force exercée lors du saut */
    #define JUMP_FORCE 10

    /* Images par seconde (IPS) */
    #define FPS_LIMIT 60

#endif