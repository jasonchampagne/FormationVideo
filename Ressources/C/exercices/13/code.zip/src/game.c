#include "settings.h"
#include "game.h"
#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>


// Vos implémentations de fonctions ici...