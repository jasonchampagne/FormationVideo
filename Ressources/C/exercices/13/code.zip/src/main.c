/*
EXERCICE C #13
[Révision : tout]

> Le but de cet exercice est de vous faire travailler avec des éléments de la SDL (comme Rect), tout en mettant à contribution vos connaissances globales en C pour simuler un peu de physique (collisions, mouvement et gravité).

> Le programme consiste à générer sur votre fenêtre un sol sur lequel est posé un cube. Lorsque l'utilisateur appuie sur la touche Espace, le cube effectue un saut, tout en étant soumis à une gravité qui le fait ensuite retomber au sol.

> Il y aura (sans doute) quelques recherches à faire en Physique, pour l'adaptation de formules qui serviront au programme (indices : accélération, chute libre, équations sur le MRUA)

> Indications :
    - utilisez le code de base fourni (si vous lisez ceci, c'est que vous y êtes)
    - produisez un saut et une chute suffisamment réalistes (comme le serait un corps sur Terre)
    - le programme doit prendre en charge les paramètres (entête "settings.h")
    - gérez bien les cas d'erreur, testez les retours des fonctions si nécessaire
    - pas de variables globales 😎
    - là encore, n'oubliez pas la documentation de la SDL
*/
#include "settings.h"
#include "game.h"
#include <SDL2/SDL.h>
#include <stdio.h>


int main(int argc, char** argv)
{
    SDL_Window* window = NULL;
    SDL_Renderer* renderer = NULL;
    struct Cube* cube = NULL;

    // 0. Initialiser le jeu (fenêtre, rendu, cube)

    while(1)
    {
        // 1. Capturer les évènements
        // 2. Mettre à jour les éléments
        // 3. Rafraîchir le rendu

        // 4. Limiter le nombre d'IPS (60 ips ~= 16ms)
        SDL_Delay(1000 / FPS_LIMIT);
    }

    return 0;
}
