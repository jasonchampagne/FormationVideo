"""
EXERCICE PYTHON #12
[Révision : tkinter, gestion du temps]

> Vous allez écrire un minuteur intégré dans une interface graphique tkinter.

    - Au lancement du programme, un minuteur (00:00:00) est affiché avec un bouton au dessous.
    - Lorsque l'utilisateur clique sur le bouton, le minuteur démarre et le temps s'actualise en direct.
    - Un clic sur le bouton met en pause le minuteur, qui peut être remis en marche avec un nouveau clic, à partir
      du temps déjà écoulé (il n'est pas remis à zéro).

> Indications :

    - écrivez votre programme dans une classe (qui héritera de tkinter.Tk) composée de plusieurs méthodes.
    - pour mettre à jour le minuteur toutes les secondes, utilisez la méthode after() à partir de votre instance TimerGUI.
        > <widget>.after(<delay>, <callback> = None)
    - utilisez le module "tconfig.py" fourni pour les paramètres de l'application.
    - pensez à mettre à jour le texte du bouton lorsque le minuteur est en marche ou à l'arrêt.
    - gérez correctement les exceptions éventuelles.

"""
import tkinter
import time
from tconfig import TConfig


class TimerGUI(tkinter.Tk):
    def __init__(self):
        pass

    #-----------------------------------------------------------------------------------

    def format_time(self, seconds):
        minutes, seconds = divmod(seconds, 60)
        hours, minutes = divmod(minutes, 60)

        return "{:02d}:{:02d}:{:02d}".format(int(hours), int(minutes), int(seconds))


app = TimerGUI()
app.mainloop()